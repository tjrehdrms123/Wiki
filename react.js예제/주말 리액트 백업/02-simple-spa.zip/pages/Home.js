import React from 'react';

/**
 * /home 페이지를 구성하는 컴포넌트
 */
const Home = () => {
    return (
        <div>
            <h2>여기는 Home.js 파일 입니다.</h2>
        </div>
    );
};

export default Home;