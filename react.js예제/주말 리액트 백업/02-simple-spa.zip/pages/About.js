import React from "react";

/**
 * /about 페이지를 구성하는 컴포넌트
 */
const About = () => {
    return (
        <div>
            <h2>여기는 About.js 입니다.</h2>
        </div>
    );
};

export default About;
