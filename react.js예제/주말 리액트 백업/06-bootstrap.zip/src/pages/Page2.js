import React from 'react';

const Page2 = () => {
    return (
        <div className="container">
            <div className="page-header">
                <h2>Page2</h2>
            </div>
        </div>
    );
};

export default Page2;